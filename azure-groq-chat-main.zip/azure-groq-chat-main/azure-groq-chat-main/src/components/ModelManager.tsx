
import { useState } from "react";
import { Plus, Trash2, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface Model {
  id: string;
  name: string;
  isCustom?: boolean;
}

interface ModelManagerProps {
  models: Model[];
  onModelsChange: (models: Model[]) => void;
}

const ModelManager = ({ models, onModelsChange }: ModelManagerProps) => {
  const [newModelId, setNewModelId] = useState("");
  const [newModelName, setNewModelName] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const addModel = () => {
    if (!newModelId.trim() || !newModelName.trim()) {
      toast({
        title: "Error",
        description: "Please enter both model ID and name",
        variant: "destructive",
      });
      return;
    }

    if (models.some(model => model.id === newModelId)) {
      toast({
        title: "Error",
        description: "Model ID already exists",
        variant: "destructive",
      });
      return;
    }

    const newModel: Model = {
      id: newModelId,
      name: newModelName,
      isCustom: true,
    };

    onModelsChange([...models, newModel]);
    setNewModelId("");
    setNewModelName("");
    setIsDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Model added successfully",
    });
  };

  const removeModel = (modelId: string) => {
    const modelToRemove = models.find(model => model.id === modelId);
    if (modelToRemove && !modelToRemove.isCustom) {
      toast({
        title: "Error",
        description: "Cannot remove default models",
        variant: "destructive",
      });
      return;
    }

    onModelsChange(models.filter(model => model.id !== modelId));
    toast({
      title: "Success",
      description: "Model removed successfully",
    });
  };

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="border-blue-200 text-blue-700 hover:bg-blue-50">
          <Settings className="w-4 h-4 mr-2" />
          Manage Models
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-blue-900">Manage AI Models</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="model-id" className="text-blue-900">Model ID</Label>
            <Input
              id="model-id"
              placeholder="e.g., custom-model-1"
              value={newModelId}
              onChange={(e) => setNewModelId(e.target.value)}
              className="border-blue-200 focus:border-blue-500"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="model-name" className="text-blue-900">Model Name</Label>
            <Input
              id="model-name"
              placeholder="e.g., Custom Model 1"
              value={newModelName}
              onChange={(e) => setNewModelName(e.target.value)}
              className="border-blue-200 focus:border-blue-500"
            />
          </div>
          
          <Button onClick={addModel} className="w-full bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Model
          </Button>
          
          <div className="space-y-2">
            <Label className="text-blue-900">Current Models</Label>
            <Card className="max-h-48 overflow-y-auto">
              <CardContent className="p-3 space-y-2">
                {models.map((model) => (
                  <div key={model.id} className="flex items-center justify-between p-2 bg-blue-50 rounded">
                    <div>
                      <p className="text-sm text-blue-900 font-medium">{model.name}</p>
                      <p className="text-xs text-blue-600">{model.id}</p>
                    </div>
                    {model.isCustom && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => removeModel(model.id)}
                        className="border-red-200 text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ModelManager;
