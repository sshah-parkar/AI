
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

interface Model {
  id: string;
  name: string;
  isCustom?: boolean;
}

interface ModelSelectorProps {
  selectedModel: string;
  onModelChange: (model: string) => void;
  models: Model[];
}

const ModelSelector = ({ selectedModel, onModelChange, models }: ModelSelectorProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="model-select" className="text-blue-900 font-medium">
        Select AI Model
      </Label>
      <Select value={selectedModel} onValueChange={onModelChange}>
        <SelectTrigger id="model-select" className="border-blue-200 focus:border-blue-500">
          <SelectValue placeholder="Choose a model" />
        </SelectTrigger>
        <SelectContent className="bg-white border-blue-200 shadow-lg">
          {models.map((model) => (
            <SelectItem key={model.id} value={model.id} className="hover:bg-blue-50">
              {model.name}
              {model.isCustom && <span className="ml-2 text-xs text-blue-600">(Custom)</span>}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default ModelSelector;
