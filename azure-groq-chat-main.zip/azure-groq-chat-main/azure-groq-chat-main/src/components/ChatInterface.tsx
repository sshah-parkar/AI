import { useState, useRef, useEffect } from "react";
import { Send, Bot, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import MessageBubble from "./MessageBubble";
import ModelSelector from "./ModelSelector";
import ModelManager from "./ModelManager";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

interface Model {
  id: string;
  name: string;
  isCustom?: boolean;
}

const ChatInterface = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const [selectedModel, setSelectedModel] = useState("llama3-8b-8192");
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [models, setModels] = useState<Model[]>([
    { id: "llama3-8b-8192", name: "Llama 3 8B" },
    { id: "llama3-70b-8192", name: "Llama 3 70B" },
    { id: "mixtral-8x7b-32768", name: "Mixtral 8x7B" },
    { id: "gemma-7b-it", name: "Gemma 7B" },
    { id: "gemma2-9b-it", name: "Gemma 2 9B" },
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Check if API key exists in localStorage
    const savedApiKey = localStorage.getItem("groq-api-key");
    const savedModel = localStorage.getItem("groq-selected-model");
    const savedModels = localStorage.getItem("groq-models");
    
    if (savedApiKey) {
      setApiKey(savedApiKey);
    } else {
      setShowApiKeyInput(true);
    }
    
    if (savedModel) {
      setSelectedModel(savedModel);
    }

    if (savedModels) {
      try {
        setModels(JSON.parse(savedModels));
      } catch (error) {
        console.error("Error parsing saved models:", error);
      }
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const saveApiKey = () => {
    if (!apiKey.trim()) {
      toast({
        title: "Error",
        description: "Please enter a valid API key",
        variant: "destructive",
      });
      return;
    }
    localStorage.setItem("groq-api-key", apiKey);
    setShowApiKeyInput(false);
    toast({
      title: "Success",
      description: "API key saved successfully!",
    });
  };

  const handleModelChange = (model: string) => {
    setSelectedModel(model);
    localStorage.setItem("groq-selected-model", model);
    toast({
      title: "Model Updated",
      description: `Switched to ${model}`,
    });
  };

  const handleModelsChange = (newModels: Model[]) => {
    setModels(newModels);
    localStorage.setItem("groq-models", JSON.stringify(newModels));
  };

  const sendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isUser: true,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);

    try {
      const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: selectedModel,
          messages: [
            {
              role: "system",
              content: "You are a helpful AI assistant. Provide clear, concise, and helpful responses."
            },
            {
              role: "user",
              content: inputValue
            }
          ],
          temperature: 0.7,
          max_tokens: 1000,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const aiResponse = data.choices[0]?.message?.content || "I apologize, but I couldn't generate a response.";

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse,
        isUser: false,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error("Error calling Groq API:", error);
      toast({
        title: "Error",
        description: "Failed to get response from AI. Please check your API key and try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  if (showApiKeyInput) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-blue-100">
        <Card className="w-full max-w-md border-blue-200 shadow-xl">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2">
              <Bot className="w-5 h-5" />
              Setup AI Assistant
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="api-key" className="text-blue-900 font-medium">
                Enter your Groq API Key
              </Label>
              <Input
                id="api-key"
                type="password"
                placeholder="gsk_..."
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="border-blue-200 focus:border-blue-500"
              />
            </div>
            
            <ModelSelector 
              selectedModel={selectedModel} 
              onModelChange={handleModelChange}
              models={models}
            />
            
            <Alert className="border-blue-200 bg-blue-50">
              <Info className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-700">
                Your API key will be stored securely in your browser.
              </AlertDescription>
            </Alert>
            
            <Button 
              onClick={saveApiKey} 
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              Start Chatting
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      {/* Header */}
      <div className="bg-white border-b border-blue-200 shadow-sm">
        <div className="flex items-center justify-between p-4 max-w-4xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-blue-900">AI Assistant</h1>
              <p className="text-sm text-blue-600">Model: {selectedModel}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <ModelManager 
              models={models}
              onModelsChange={handleModelsChange}
            />
            <ModelSelector 
              selectedModel={selectedModel} 
              onModelChange={handleModelChange}
              models={models}
            />
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.length === 0 && (
            <div className="text-center py-12">
              <Bot className="w-12 h-12 text-blue-400 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-blue-900 mb-2">
                Welcome to AI Assistant
              </h2>
              <p className="text-blue-600">
                Start a conversation by typing a message below.
              </p>
            </div>
          )}
          
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))}
          
          {isLoading && (
            <MessageBubble
              message={{
                id: "loading",
                text: "Thinking...",
                isUser: false,
                timestamp: new Date(),
              }}
              isLoading={true}
            />
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-blue-200 bg-white p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex gap-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1 border-blue-200 focus:border-blue-500 focus:ring-blue-500"
              disabled={isLoading}
            />
            <Button
              onClick={sendMessage}
              disabled={isLoading || !inputValue.trim()}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
