
export const formatMarkdownText = (text: string): string => {
  // Replace **text** with proper bold formatting
  let formatted = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  
  // Replace *text* with proper italic formatting
  formatted = formatted.replace(/\*(.*?)\*/g, '<em>$1</em>');
  
  // Replace numbered lists to have better spacing
  formatted = formatted.replace(/^(\d+\.\s)/gm, '\n$1');
  
  // Replace bullet points
  formatted = formatted.replace(/^[-*]\s/gm, '• ');
  
  return formatted;
};
